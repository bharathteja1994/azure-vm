All notable changes to this project will be documented in this file.

Please use semantic versioning and follow this format:

[Date] : [version]: 
- [description]
- [description]

#####################################################################
[09-05-2025] : [v1.5.0]
- Added support for role assignments using the rtlh-tf-az-role-assignment module
- Added azurerm_storage_account_network_rules resource for proper network access control
- Added new variables for network rules configuration: enable_network_rules, default_action, bypass, ip_rules, virtual_network_subnet_ids
- Added additional storage account configuration options: public_network_access_enabled, allow_nested_items_to_be_public
- Replaced azapi_update_resource for network rules with standard Terraform resources
- Removed deprecated managed_id_allowed_access variable

[08-05-2025] : [v1.4.0]
- Removed direct UMI creation via resource
- Added integration with module to create UMIs when needed
- Added support for using existing UMIs via resource ID
- Updated variables to support new UMI creation/usage methods
- Updated examples to demonstrate all UMI/CMK combinations
- Updated tests to use the role-assignment module

[07-05-2025] : [v1.3.0]
- Added support for using existing Customer Managed Keys
- Added support for creating new Customer Managed Keys
- Fixed key reference in storage account configuration
- Added is_cmk_enabled output for testing and verification
- Updated variable definitions with better descriptions and validation
- Added comprehensive examples in the examples directory
- Implemented tests for CMK functionality

[06-05-2025] : [v1.2.1]
- Fixed resource group name in local.tf

[23-01-2025] : [v1.2.0]
- Update to allow managed ID

[08-01-2025] : [V1.1.0]

- Added testing
- Updated keyvault and cmk to be optional - to be updated more later
- Updated acc key to be default true because TF uses acc key to destroy/modify stuff
- 

[13-12-2025] : [V1.0.0]

- initial commit