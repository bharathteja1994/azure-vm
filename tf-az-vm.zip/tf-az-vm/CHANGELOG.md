All notable changes to this project will be documented in this file.

Please use semantic versioning and follow this format:

[Date] : [version]: 
- [description]
- [description]

#####################################################################

[15-05-2025] : [V1.0.0]

- Initial module creation
